﻿using SoftwareVVNZ.AppCode;
using SoftwareVVNZ.Forms.Dictionary;
using SoftwareVVNZ.Forms.Forming;
using SoftwareVVNZ.Forms.Raport;
using SoftwareVVNZ.Forms.Systems;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoftwareVVNZ
{
    public partial class SoftwareMDI : Form
    {

        public SoftwareMDI()
        {
            InitializeComponent();
            EnabledFalse();
        }

        private void EnabledFalse()
        {
            if (LoginForm.CurrentUser.RoleId == 3)
            {
                відомостіToolStripMenuItem.Enabled = false;
            }
            
        }

        public void CloseAllWindows()
        {
            Form[] childArray = this.MdiChildren;
            foreach (Form childForm in childArray)
            {
                childForm.Close();
            }
        }


        private void відомостіToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllWindows();
            StatementsForm statementsForm = new StatementsForm();
            statementsForm.MdiParent = this;
            statementsForm.WindowState = FormWindowState.Maximized;
            statementsForm.Show();
        }

        private void вихідToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void дисципліниToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllWindows();
            DisciplineForm disciplineForm = new DisciplineForm();
            disciplineForm.MdiParent = this;
            disciplineForm.WindowState = FormWindowState.Maximized;
            disciplineForm.Show();
        }

        private void групиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllWindows();
            GroupsForm groupsForm = new GroupsForm();
            groupsForm.MdiParent = this;
            groupsForm.WindowState = FormWindowState.Maximized;
            groupsForm.Show();
        }

        private void студентиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllWindows();
            StudentForm studentForm = new StudentForm();
            studentForm.MdiParent = this;
            studentForm.WindowState = FormWindowState.Maximized;
            studentForm.Show();
        }

        private void зведенаВідомістьЗаГрупуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllWindows();
            SummaryStatementGroupForm summaryStatementGroupForm = new SummaryStatementGroupForm();
            summaryStatementGroupForm.MdiParent = this;
            summaryStatementGroupForm.WindowState = FormWindowState.Maximized;
            summaryStatementGroupForm.Show();
        }

        private void рейтингСлухачівСпеціальностіПоКурсамToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllWindows();
            RatingStudentsMajoringForm ratingStudentsMajoringForm = new RatingStudentsMajoringForm();
            ratingStudentsMajoringForm.MdiParent = this;
            ratingStudentsMajoringForm.WindowState = FormWindowState.Maximized;
            ratingStudentsMajoringForm.Show();
        }

        private void стипендіяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllWindows();
            ScholarshipForm scholarshipForm = new ScholarshipForm();
            scholarshipForm.MdiParent = this;
            scholarshipForm.WindowState = FormWindowState.Maximized;
            scholarshipForm.Show();
        }

        private void випискаЗаРезультатамиНавчанняЗаСеместрToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllWindows();
            ExtractResultsForSemesterForm extractResultsForSemesterForm = new ExtractResultsForSemesterForm();
            extractResultsForSemesterForm.MdiParent = this;
            extractResultsForSemesterForm.WindowState = FormWindowState.Maximized;
            extractResultsForSemesterForm.Show();
        }

        private void додатокДоДипломуПроВищуОсвітуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllWindows();
            DiplomaSupplementForm diplomaSupplementForm = new DiplomaSupplementForm();
            diplomaSupplementForm.MdiParent = this;
            diplomaSupplementForm.WindowState = FormWindowState.Maximized;
            diplomaSupplementForm.Show();
        }

        private void користувачіToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (LoginForm.CurrentUser.RoleId == 1)
            {
                CloseAllWindows();
                UsersForm usersForm = new UsersForm();
                usersForm.MdiParent = this;
                usersForm.WindowState = FormWindowState.Maximized;
                usersForm.Show();
            }
            else
            {
                MessageBox.Show(NamesMy.MessageBoxExaption.YouDontHavePermission);
            }
        }

        private void системнийЖурналToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (LoginForm.CurrentUser.RoleId == 1)
            {
                CloseAllWindows();
                SystemLogForm systemLogForm = new SystemLogForm();
                systemLogForm.MdiParent = this;
                systemLogForm.WindowState = FormWindowState.Maximized;
                systemLogForm.Show();
            }
            else
            {
                MessageBox.Show(NamesMy.MessageBoxExaption.YouDontHavePermission);
            }
        }

        private void викладачіToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllWindows();
            TeacherForm studentForm = new TeacherForm();
            studentForm.MdiParent = this;
            studentForm.WindowState = FormWindowState.Maximized;
            studentForm.Show();
        }
    }
}
