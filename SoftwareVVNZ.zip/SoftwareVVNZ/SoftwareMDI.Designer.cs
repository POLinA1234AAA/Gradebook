﻿namespace SoftwareVVNZ {
  partial class SoftwareMDI {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if (disposing && (components != null)) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.формуванняToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.відомостіToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вихідToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.довідникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.дисципліниToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.групиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.студентиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.звітиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.зведенаВідомістьЗаГрупуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.рейтингСлухачівСпеціальностіПоКурсамToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.стипендіяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.випискаЗаРезультатамиНавчанняЗаСеместрToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.додатокДоДипломуПроВищуОсвітуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.системаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.користувачіToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.системнийЖурналToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.викладачіToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.формуванняToolStripMenuItem,
            this.довідникиToolStripMenuItem,
            this.звітиToolStripMenuItem,
            this.системаToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(1092, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // формуванняToolStripMenuItem
            // 
            this.формуванняToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.відомостіToolStripMenuItem,
            this.вихідToolStripMenuItem});
            this.формуванняToolStripMenuItem.Name = "формуванняToolStripMenuItem";
            this.формуванняToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.формуванняToolStripMenuItem.Text = "Формування";
            // 
            // відомостіToolStripMenuItem
            // 
            this.відомостіToolStripMenuItem.Name = "відомостіToolStripMenuItem";
            this.відомостіToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.відомостіToolStripMenuItem.Text = "Відомості";
            this.відомостіToolStripMenuItem.Click += new System.EventHandler(this.відомостіToolStripMenuItem_Click);
            // 
            // вихідToolStripMenuItem
            // 
            this.вихідToolStripMenuItem.Name = "вихідToolStripMenuItem";
            this.вихідToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.вихідToolStripMenuItem.Text = "Вихід";
            this.вихідToolStripMenuItem.Click += new System.EventHandler(this.вихідToolStripMenuItem_Click);
            // 
            // довідникиToolStripMenuItem
            // 
            this.довідникиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.дисципліниToolStripMenuItem,
            this.групиToolStripMenuItem,
            this.студентиToolStripMenuItem,
            this.викладачіToolStripMenuItem});
            this.довідникиToolStripMenuItem.Name = "довідникиToolStripMenuItem";
            this.довідникиToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.довідникиToolStripMenuItem.Text = "Довідники";
            // 
            // дисципліниToolStripMenuItem
            // 
            this.дисципліниToolStripMenuItem.Name = "дисципліниToolStripMenuItem";
            this.дисципліниToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.дисципліниToolStripMenuItem.Text = "Дисципліни";
            this.дисципліниToolStripMenuItem.Click += new System.EventHandler(this.дисципліниToolStripMenuItem_Click);
            // 
            // групиToolStripMenuItem
            // 
            this.групиToolStripMenuItem.Name = "групиToolStripMenuItem";
            this.групиToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.групиToolStripMenuItem.Text = "Групи";
            this.групиToolStripMenuItem.Click += new System.EventHandler(this.групиToolStripMenuItem_Click);
            // 
            // студентиToolStripMenuItem
            // 
            this.студентиToolStripMenuItem.Name = "студентиToolStripMenuItem";
            this.студентиToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.студентиToolStripMenuItem.Text = "Слухачі";
            this.студентиToolStripMenuItem.Click += new System.EventHandler(this.студентиToolStripMenuItem_Click);
            // 
            // звітиToolStripMenuItem
            // 
            this.звітиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.зведенаВідомістьЗаГрупуToolStripMenuItem,
            this.рейтингСлухачівСпеціальностіПоКурсамToolStripMenuItem,
            this.стипендіяToolStripMenuItem,
            this.випискаЗаРезультатамиНавчанняЗаСеместрToolStripMenuItem,
            this.додатокДоДипломуПроВищуОсвітуToolStripMenuItem});
            this.звітиToolStripMenuItem.Name = "звітиToolStripMenuItem";
            this.звітиToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.звітиToolStripMenuItem.Text = "Звіти";
            // 
            // зведенаВідомістьЗаГрупуToolStripMenuItem
            // 
            this.зведенаВідомістьЗаГрупуToolStripMenuItem.Name = "зведенаВідомістьЗаГрупуToolStripMenuItem";
            this.зведенаВідомістьЗаГрупуToolStripMenuItem.Size = new System.Drawing.Size(329, 22);
            this.зведенаВідомістьЗаГрупуToolStripMenuItem.Text = "Зведена відомість за групу ";
            this.зведенаВідомістьЗаГрупуToolStripMenuItem.Click += new System.EventHandler(this.зведенаВідомістьЗаГрупуToolStripMenuItem_Click);
            // 
            // рейтингСлухачівСпеціальностіПоКурсамToolStripMenuItem
            // 
            this.рейтингСлухачівСпеціальностіПоКурсамToolStripMenuItem.Name = "рейтингСлухачівСпеціальностіПоКурсамToolStripMenuItem";
            this.рейтингСлухачівСпеціальностіПоКурсамToolStripMenuItem.Size = new System.Drawing.Size(329, 22);
            this.рейтингСлухачівСпеціальностіПоКурсамToolStripMenuItem.Text = "Рейтинг слухачів спеціальності по курсам";
            this.рейтингСлухачівСпеціальностіПоКурсамToolStripMenuItem.Click += new System.EventHandler(this.рейтингСлухачівСпеціальностіПоКурсамToolStripMenuItem_Click);
            // 
            // стипендіяToolStripMenuItem
            // 
            this.стипендіяToolStripMenuItem.Name = "стипендіяToolStripMenuItem";
            this.стипендіяToolStripMenuItem.Size = new System.Drawing.Size(329, 22);
            this.стипендіяToolStripMenuItem.Text = "Стипендія";
            this.стипендіяToolStripMenuItem.Click += new System.EventHandler(this.стипендіяToolStripMenuItem_Click);
            // 
            // випискаЗаРезультатамиНавчанняЗаСеместрToolStripMenuItem
            // 
            this.випискаЗаРезультатамиНавчанняЗаСеместрToolStripMenuItem.Name = "випискаЗаРезультатамиНавчанняЗаСеместрToolStripMenuItem";
            this.випискаЗаРезультатамиНавчанняЗаСеместрToolStripMenuItem.Size = new System.Drawing.Size(329, 22);
            this.випискаЗаРезультатамиНавчанняЗаСеместрToolStripMenuItem.Text = "Виписка за результатами навчання за семестр";
            this.випискаЗаРезультатамиНавчанняЗаСеместрToolStripMenuItem.Click += new System.EventHandler(this.випискаЗаРезультатамиНавчанняЗаСеместрToolStripMenuItem_Click);
            // 
            // додатокДоДипломуПроВищуОсвітуToolStripMenuItem
            // 
            this.додатокДоДипломуПроВищуОсвітуToolStripMenuItem.Name = "додатокДоДипломуПроВищуОсвітуToolStripMenuItem";
            this.додатокДоДипломуПроВищуОсвітуToolStripMenuItem.Size = new System.Drawing.Size(329, 22);
            this.додатокДоДипломуПроВищуОсвітуToolStripMenuItem.Text = "Додаток до диплому про вищу освіту";
            this.додатокДоДипломуПроВищуОсвітуToolStripMenuItem.Click += new System.EventHandler(this.додатокДоДипломуПроВищуОсвітуToolStripMenuItem_Click);
            // 
            // системаToolStripMenuItem
            // 
            this.системаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.користувачіToolStripMenuItem,
            this.системнийЖурналToolStripMenuItem});
            this.системаToolStripMenuItem.Name = "системаToolStripMenuItem";
            this.системаToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.системаToolStripMenuItem.Text = "Система";
            // 
            // користувачіToolStripMenuItem
            // 
            this.користувачіToolStripMenuItem.Name = "користувачіToolStripMenuItem";
            this.користувачіToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.користувачіToolStripMenuItem.Text = "Користувачі";
            this.користувачіToolStripMenuItem.Click += new System.EventHandler(this.користувачіToolStripMenuItem_Click);
            // 
            // системнийЖурналToolStripMenuItem
            // 
            this.системнийЖурналToolStripMenuItem.Name = "системнийЖурналToolStripMenuItem";
            this.системнийЖурналToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.системнийЖурналToolStripMenuItem.Text = "Системний журнал";
            this.системнийЖурналToolStripMenuItem.Click += new System.EventHandler(this.системнийЖурналToolStripMenuItem_Click);
            // 
            // викладачіToolStripMenuItem
            // 
            this.викладачіToolStripMenuItem.Name = "викладачіToolStripMenuItem";
            this.викладачіToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.викладачіToolStripMenuItem.Text = "Викладачі";
            this.викладачіToolStripMenuItem.Click += new System.EventHandler(this.викладачіToolStripMenuItem_Click);
            // 
            // SoftwareMDI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1092, 556);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "SoftwareMDI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Програмний модуль автоматизації обліку успішності слухачів ВВНЗ";
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

    }
    #endregion


    private System.Windows.Forms.MenuStrip menuStrip;
    private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem формуванняToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem відомостіToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вихідToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem довідникиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem дисципліниToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem групиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem студентиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem звітиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem зведенаВідомістьЗаГрупуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem рейтингСлухачівСпеціальностіПоКурсамToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem стипендіяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem випискаЗаРезультатамиНавчанняЗаСеместрToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem додатокДоДипломуПроВищуОсвітуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem системаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem користувачіToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem системнийЖурналToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem викладачіToolStripMenuItem;
    }
}



